import { i as __toESM } from "../_runtime.mjs";
import { a as Overlay2, c as Title2, f as require_jsx_runtime, i as Description2, l as Trigger2, n as Cancel, o as Portal2, p as require_react, r as Content2, s as Root2, t as Action, u as Slot } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as genderFromWord, i as emptyPerson, n as REL_LABELS, o as inferGenderFromName, r as UNION_TYPES, s as personYears, t as PARENT_TYPES } from "./gender-IpsWIfkz.mjs";
import { a as UnfoldHorizontal, c as Sparkles, d as Plus, f as Minus, g as Download, h as FileJson, i as Upload, l as RotateCw, m as Link2, n as Users, p as Maximize2, r as UserPlus, s as Trash2, t as WandSparkles, u as RotateCcw } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DVrS2q3W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,box-shadow,color] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90 shadow-[var(--shadow-border)]",
			secondary: "bg-secondary text-secondary-foreground hover:bg-accent",
			outline: "border border-border bg-card text-foreground hover:bg-accent",
			ghost: "text-foreground hover:bg-accent",
			destructive: "bg-destructive text-destructive-foreground hover:opacity-90"
		},
		size: {
			default: "h-10 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-11 px-5",
			icon: "size-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var AlertDialog = Root2;
var AlertDialogTrigger = Trigger2;
var AlertDialogPortal = Portal2;
function AlertDialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
		className: cn("fixed inset-0 z-50 bg-[color-mix(in_oklab,var(--color-foreground)_28%,transparent)]", className),
		...props
	});
}
function AlertDialogContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(92vw,400px)] -translate-x-1/2 -translate-y-1/2 rounded-xl bg-card p-5 text-card-foreground shadow-[var(--shadow-border)]", className),
		...props
	})] });
}
function AlertDialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-2", className),
		...props
	});
}
function AlertDialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
		className: cn("font-display text-xl font-medium tracking-tight", className),
		...props
	});
}
function AlertDialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function AlertDialogFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mt-5 flex justify-end gap-2", className),
		...props
	});
}
function AlertDialogAction({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
		className: cn(buttonVariants(), className),
		...props
	});
}
function AlertDialogCancel({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
		className: cn(buttonVariants({ variant: "outline" }), className),
		...props
	});
}
var COL = 128;
var ROW = 158;
var COUPLE = 108;
var MIN = 112;
var TOP = 72;
function autoLayout(persons, relationships) {
	if (persons.length === 0) return persons;
	const ids = persons.map((p) => p.id);
	const byId = new Map(persons.map((p) => [p.id, { ...p }]));
	const parentsOf = /* @__PURE__ */ new Map();
	const childrenOf = /* @__PURE__ */ new Map();
	for (const r of relationships) {
		if (!PARENT_TYPES.includes(r.type)) continue;
		parentsOf.set(r.b, [...parentsOf.get(r.b) ?? [], r.a]);
		childrenOf.set(r.a, [...childrenOf.get(r.a) ?? [], r.b]);
	}
	const gen = /* @__PURE__ */ new Map();
	const visiting = /* @__PURE__ */ new Set();
	function depth(id) {
		const cached = gen.get(id);
		if (cached != null) return cached;
		if (visiting.has(id)) return 0;
		visiting.add(id);
		const ps = parentsOf.get(id) ?? [];
		const d = ps.length === 0 ? 0 : Math.max(...ps.map(depth)) + 1;
		visiting.delete(id);
		gen.set(id, d);
		return d;
	}
	ids.forEach(depth);
	const minGen = Math.min(...[...gen.values()]);
	ids.forEach((id) => gen.set(id, (gen.get(id) ?? 0) - minGen));
	const unions = [];
	for (const r of relationships) {
		if (!UNION_TYPES.includes(r.type)) continue;
		unions.push({
			a: r.a,
			b: r.b,
			type: r.type
		});
	}
	const rows = [];
	for (const id of ids) {
		const g = gen.get(id) ?? 0;
		if (!rows[g]) rows[g] = [];
		rows[g].push(id);
	}
	function parentKey(id) {
		return (parentsOf.get(id) ?? []).slice().sort().join("|");
	}
	function spouseInRow(id, row) {
		for (const u of unions) {
			const other = u.a === id ? u.b : u.b === id ? u.a : null;
			if (other && row.includes(other)) return other;
		}
		return null;
	}
	rows.forEach((row, gi) => {
		row.sort((a, b) => parentKey(a).localeCompare(parentKey(b)) || a.localeCompare(b));
		const ordered = [];
		const used = /* @__PURE__ */ new Set();
		for (const id of row) {
			if (used.has(id)) continue;
			const spouses = unions.map((u) => u.a === id ? u.b : u.b === id ? u.a : null).filter((s) => Boolean(s) && row.includes(s) && !used.has(s));
			const me = byId.get(id);
			if (spouses.length === 0) {
				ordered.push(id);
				used.add(id);
				continue;
			}
			if (spouses.length === 1) {
				const other = byId.get(spouses[0]);
				if (me.gender === "male" || other.gender === "female") ordered.push(id, spouses[0]);
				else ordered.push(spouses[0], id);
				used.add(id);
				used.add(spouses[0]);
				continue;
			}
			ordered.push(spouses[0], id, ...spouses.slice(1));
			used.add(id);
			spouses.forEach((s) => used.add(s));
		}
		for (const id of row) if (!used.has(id)) ordered.push(id);
		rows[gi] = ordered;
	});
	rows.forEach((row, gi) => {
		row.forEach((id, i) => {
			const p = byId.get(id);
			p.generation = gi;
			p.x = 90 + i * COL;
			p.y = TOP + gi * ROW;
		});
	});
	for (let iter = 0; iter < 80; iter++) {
		const t = iter < 20 ? .85 : .45;
		for (const u of unions) {
			const a = byId.get(u.a);
			const b = byId.get(u.b);
			if (!a || !b) continue;
			if (a.generation !== b.generation) continue;
			const left = a.x <= b.x ? a : b;
			const right = a.x <= b.x ? b : a;
			const mid = (left.x + right.x) / 2;
			left.x += (mid - COUPLE / 2 - left.x) * t;
			right.x += (mid + COUPLE / 2 - right.x) * t;
		}
		const groups = /* @__PURE__ */ new Map();
		for (const id of ids) {
			const ps = parentsOf.get(id) ?? [];
			if (ps.length === 0) continue;
			const key = [...ps].sort().join("|");
			const arr = groups.get(key) ?? [];
			arr.push(id);
			groups.set(key, arr);
		}
		for (const [key, children] of groups) {
			const pxs = key.split("|").map((id) => byId.get(id)?.x).filter((x) => x != null);
			if (!pxs.length) continue;
			const mid = pxs.reduce((s, x) => s + x, 0) / pxs.length;
			const unique = [...new Set(children)].sort((a, b) => byId.get(a).x - byId.get(b).x);
			const start = mid - (unique.length - 1) * COL / 2;
			unique.forEach((id, i) => {
				const p = byId.get(id);
				p.x += (start + i * COL - p.x) * t;
			});
		}
		rows.forEach((row) => {
			const sorted = [...row].sort((a, b) => byId.get(a).x - byId.get(b).x);
			for (let i = 1; i < sorted.length; i++) {
				const prev = byId.get(sorted[i - 1]);
				const cur = byId.get(sorted[i]);
				const min = spouseInRow(prev.id, row) === cur.id ? COUPLE : MIN;
				const gap = cur.x - prev.x;
				if (gap < min) {
					const push = (min - gap) / 2;
					prev.x -= push;
					cur.x += push;
				}
			}
		});
	}
	let minX = Infinity;
	for (const p of byId.values()) minX = Math.min(minX, p.x);
	const shift = 90 - minX;
	for (const p of byId.values()) p.x += shift;
	return ids.map((id) => byId.get(id));
}
function boundingBox(persons, pad = 80, minW = 0, minH = 0) {
	if (persons.length === 0) return {
		minX: 0,
		minY: 0,
		width: Math.max(minW, 800),
		height: Math.max(minH, 500)
	};
	let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
	for (const p of persons) {
		minX = Math.min(minX, p.x - 28);
		maxX = Math.max(maxX, p.x + 28);
		minY = Math.min(minY, p.y - 28);
		maxY = Math.max(maxY, p.y + 58);
	}
	return {
		minX: minX - pad,
		minY: minY - pad,
		width: Math.max(minW, maxX - minX + pad * 2),
		height: Math.max(minH, maxY - minY + pad * 2)
	};
}
function downloadBlob(filename, blob) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
function exportSvgElement(svg, filename = "genograma.svg") {
	const clone = svg.cloneNode(true);
	clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
	clone.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
	downloadBlob(filename, new Blob([new XMLSerializer().serializeToString(clone)], { type: "image/svg+xml;charset=utf-8" }));
}
async function exportPngElement(svg, filename = "genograma.png") {
	const clone = svg.cloneNode(true);
	clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
	const vb = svg.viewBox.baseVal;
	const width = Math.max(800, (vb.width || svg.clientWidth || 900) * 2);
	const height = Math.max(500, (vb.height || svg.clientHeight || 560) * 2);
	clone.setAttribute("width", String(width));
	clone.setAttribute("height", String(height));
	const xml = new XMLSerializer().serializeToString(clone);
	const url = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml);
	const img = new Image();
	await new Promise((resolve, reject) => {
		img.onload = () => resolve();
		img.onerror = () => reject(/* @__PURE__ */ new Error("No se pudo rasterizar el SVG"));
		img.src = url;
	});
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	ctx.fillStyle = "#f7f8fa";
	ctx.fillRect(0, 0, width, height);
	ctx.drawImage(img, 0, 0, width, height);
	await new Promise((resolve) => {
		canvas.toBlob((blob) => {
			if (blob) downloadBlob(filename, blob);
			resolve();
		}, "image/png");
	});
}
var TOKEN = String.raw`\p{Lu}\p{L}+(?:-\p{Lu}\p{L}+)?`;
var PARTICLE = String.raw`(?:de(?:l|\s+l[ao]s?)?\s+)?`;
var NAME = String.raw`${TOKEN}(?:\s+${PARTICLE}${TOKEN})?`;
var AGE = String.raw`(?:de\s+)?(\d{1,3})(?:\s*años?)?`;
var STOP = new Set([
	"Los",
	"Las",
	"El",
	"La",
	"De",
	"Del",
	"En",
	"Con",
	"Un",
	"Una",
	"Uno",
	"Y",
	"E",
	"O",
	"Tienen",
	"Tiene",
	"Tuvo",
	"Tuvieron",
	"Tengo",
	"Tuve",
	"Tenemos",
	"Tuvimos",
	"Padres",
	"Padre",
	"Madre",
	"Hijos",
	"Hijo",
	"Hija",
	"Falleció",
	"Fallecio",
	"Murió",
	"Murio",
	"Años",
	"Anos",
	"Llamada",
	"Llamado",
	"Llaman",
	"Llama",
	"Llamo",
	"Se",
	"Me",
	"Mi",
	"Mis",
	"Yo",
	"Estoy",
	"Somos",
	"Está",
	"Esta",
	"Están",
	"Estan",
	"Estaba",
	"Estaban",
	"Casada",
	"Casado",
	"Casados",
	"Casadas",
	"Casé",
	"Case",
	"Divorciada",
	"Divorciado",
	"Divorciados",
	"Separados",
	"Separada",
	"Separado",
	"Hermana",
	"Hermano",
	"Hermanos",
	"Hermanas",
	"Dos",
	"Tres",
	"Cuatro",
	"Cinco",
	"Seis",
	"Siete",
	"Ocho",
	"Nueve",
	"Diez",
	"Ellos",
	"Ellas",
	"También",
	"Tambien",
	"Además",
	"Ademas",
	"Pero",
	"Por",
	"Para",
	"Su",
	"Sus",
	"Nuestro",
	"Nuestra",
	"Nuestros",
	"Nuestras",
	"Al",
	"Lo",
	"Le",
	"Les",
	"Que",
	"Como",
	"Año",
	"Ano",
	"Mes",
	"Hoy",
	"Ahora",
	"Don",
	"Doña",
	"Dona",
	"Paciente",
	"Identificado",
	"Identificada",
	"Familia",
	"Genograma",
	"Abuelo",
	"Abuela",
	"Abuelos",
	"Abuelas",
	"Tío",
	"Tio",
	"Tía",
	"Tia",
	"Nieto",
	"Nieta",
	"Nietos",
	"Vive",
	"Viven",
	"Convive",
	"Conviven",
	"Nació",
	"Nacio",
	"Nacida",
	"Nacido",
	"Fue",
	"Fueron",
	"Era",
	"Eran",
	"Es",
	"Son",
	"Adoptada",
	"Adoptado",
	"Adoptados",
	"Mantiene",
	"Mantienen",
	"Hay",
	"Muy",
	"Cercana",
	"Cercano",
	"Cercanas",
	"Cercanos",
	"Distante",
	"Distantes",
	"Cortó",
	"Corto",
	"Rompió",
	"Rompio",
	"Relación",
	"Relacion",
	"Conflicto",
	"Índice",
	"Indice",
	"Viudo",
	"Viuda",
	"Exesposo",
	"Exesposa",
	"Esposo",
	"Esposa",
	"Marido",
	"Mujer",
	"Hombre",
	"Enero",
	"Febrero",
	"Marzo",
	"Abril",
	"Mayo",
	"Junio",
	"Julio",
	"Agosto",
	"Septiembre",
	"Octubre",
	"Noviembre",
	"Diciembre"
].map((w) => w.toLowerCase()));
function isNameToken(token) {
	return new RegExp(`^${TOKEN}$`, "u").test(token) && !STOP.has(token.toLowerCase());
}
function titleCase(name) {
	return name.split(/\s+/).map((part) => part.split("-").map((bit) => {
		if (!bit) return bit;
		if ([
			"de",
			"del",
			"la",
			"las",
			"los"
		].includes(bit.toLowerCase())) return bit.toLowerCase();
		return bit.charAt(0).toUpperCase() + bit.slice(1).toLowerCase();
	}).join("-")).join(" ");
}
function cleanName(raw) {
	const parts = raw.trim().replace(/^(el|la|los|las|don|doña|dona)\s+/i, "").split(/\s+/).filter((part) => {
		if ([
			"de",
			"del",
			"la",
			"las",
			"los"
		].includes(part.toLowerCase())) return true;
		return isNameToken(part.charAt(0).toUpperCase() + part.slice(1));
	});
	if (parts.length === 0) return "";
	return titleCase(parts.slice(0, 3).join(" "));
}
var EXAMPLE_TEXT = `María de 45 años está casada con Juan de 48.
Tienen dos hijos: Laura de 15 y Pedro de 12.
Los padres de María se llaman Carmen y José.
José falleció en 2018.
María tiene una hermana llamada Ana.`;
function makeBuilder() {
	return {
		persons: [],
		relationships: [],
		nameToId: {},
		nextP: 1,
		nextR: 1,
		selfId: null
	};
}
function getOrCreate(b, rawName, opts = {}) {
	const name = cleanName(rawName);
	if (!name) return "";
	const key = name.toLowerCase();
	const existingId = b.nameToId[key];
	if (existingId) {
		const p = b.persons.find((x) => x.id === existingId);
		if (p) {
			if (opts.age != null && p.age == null) p.age = opts.age;
			if (opts.deceased) p.deceased = true;
			if (opts.deathYear) p.deathYear = opts.deathYear;
			if (opts.birthYear && p.birthYear == null) p.birthYear = opts.birthYear;
			if (opts.identifiedPatient) p.identifiedPatient = true;
			if (opts.gender && opts.gender !== "unknown" && p.gender === "unknown") p.gender = opts.gender;
		}
		return existingId;
	}
	const id = `p${b.nextP++}`;
	b.nameToId[key] = id;
	const gender = opts.gender && opts.gender !== "unknown" ? opts.gender : inferGenderFromName(name);
	b.persons.push(emptyPerson({
		id,
		name,
		gender,
		age: opts.age ?? null,
		deceased: Boolean(opts.deceased),
		deathYear: opts.deathYear ?? null,
		birthYear: opts.birthYear ?? null,
		identifiedPatient: Boolean(opts.identifiedPatient)
	}));
	return id;
}
function ensureSelf(b, opts = {}) {
	if (b.selfId) {
		const p = b.persons.find((x) => x.id === b.selfId);
		if (p && opts.gender && opts.gender !== "unknown" && p.gender === "unknown") p.gender = opts.gender;
		return b.selfId;
	}
	const id = getOrCreate(b, "Consultante", {
		identifiedPatient: true,
		gender: opts.gender ?? "unknown"
	});
	b.selfId = id;
	return id;
}
function nameSelf(b, rawName, opts = {}) {
	const name = cleanName(rawName);
	if (!name) return ensureSelf(b, opts);
	if (b.selfId) {
		const p = b.persons.find((x) => x.id === b.selfId);
		if (p) {
			if (p.name === "Consultante") {
				delete b.nameToId["consultante"];
				p.name = name;
				b.nameToId[name.toLowerCase()] = p.id;
			}
			if (opts.gender && opts.gender !== "unknown") p.gender = opts.gender;
			if (opts.age != null) p.age = opts.age;
			p.identifiedPatient = true;
			return p.id;
		}
	}
	const id = getOrCreate(b, name, {
		...opts,
		identifiedPatient: true
	});
	b.selfId = id;
	return id;
}
function addRel(b, type, a, bId) {
	if (!a || !bId || a === bId) return;
	if (b.relationships.some((r) => r.type === type && (r.a === a && r.b === bId || r.a === bId && r.b === a))) return;
	b.relationships.push({
		id: `r${b.nextR++}`,
		type,
		a,
		b: bId
	});
}
function ageNear(sentence, name) {
	const re = new RegExp(`${name}\\s+(?:de\\s+)?(\\d{1,3})(?:\\s*años?)?`, "iu");
	const m = sentence.match(re);
	if (m) return Number(m[1]);
	return null;
}
function parseNamedPeople(chunk) {
	const parts = chunk.split(/,|;| y | e /i).map((s) => s.trim()).filter(Boolean);
	const out = [];
	for (const part of parts) {
		const m = part.match(new RegExp(`^(${NAME})(?:\\s+${AGE})?`, "u"));
		if (!m) continue;
		const name = cleanName(m[1]);
		if (!name) continue;
		const age = m[2] ? Number(m[2]) : null;
		const gender = genderFromWord(part);
		out.push({
			name,
			age,
			gender
		});
	}
	return out;
}
function lastUnion(b) {
	const u = [...b.relationships].reverse().find((r) => UNION_TYPES.includes(r.type));
	return u ? {
		a: u.a,
		b: u.b
	} : null;
}
function parentsOf(b, id) {
	return b.relationships.filter((r) => PARENT_TYPES.includes(r.type) && r.b === id).map((r) => r.a);
}
function idsMentioned(b, sentence, exclude = []) {
	const ex = new Set(exclude.map((n) => n.toLowerCase()));
	return b.persons.filter((p) => !ex.has(p.name.toLowerCase()) && sentence.toLowerCase().includes(p.name.toLowerCase())).map((p) => p.id);
}
function parentsForChildren(b, sentence, kidNames) {
	const mentioned = idsMentioned(b, sentence, kidNames);
	if (mentioned.length) return mentioned;
	if (/\b(tengo|tuve|tenemos|tuvimos)\b/i.test(sentence)) {
		const self = ensureSelf(b);
		const union = lastUnion(b);
		if (union && (union.a === self || union.b === self)) return [union.a, union.b];
		return [self];
	}
	const union = lastUnion(b);
	return union ? [union.a, union.b] : [];
}
function preprocess(text) {
	return text.replace(/\r/g, "").replace(/\b(\p{L}[\p{L}'-]*?)\s*\((\d{1,3})\)/gu, "$1 de $2 años").replace(/\b(\p{L}[\p{L}'-]*?),\s*(\d{1,3})\s*años/giu, "$1 de $2 años").replace(/[\p{L}]+(?:-[\p{L}]+)*/gu, (word) => {
		const lower = word.toLowerCase();
		if (STOP.has(lower)) return lower;
		if ([
			"de",
			"del",
			"la",
			"las",
			"los",
			"y",
			"e"
		].includes(lower)) return lower;
		if (word.length < 2) return word;
		return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
	});
}
function parseFamilyText(text) {
	const b = makeBuilder();
	const cleaned = preprocess(text).trim();
	if (!cleaned) return {
		persons: [],
		relationships: []
	};
	const sentences = cleaned.split(/[\.\n;]+/).map((s) => s.trim()).filter(Boolean);
	for (const sentence of sentences) {
		const lower = sentence.toLowerCase();
		const deceased = /falleci[oó]|muri[oó]|difunt[oa]|está fallecid|ya no vive/.test(lower);
		const deathYearMatch = lower.match(/falleci[oó]\s+en\s+(\d{4})|muri[oó]\s+en\s+(\d{4})|en\s+(\d{4})\s+falleci/);
		const deathYear = deathYearMatch ? Number(deathYearMatch[1] || deathYearMatch[2] || deathYearMatch[3]) : null;
		const birthYearMatch = lower.match(/naci[oó]\s+en\s+(\d{4})/);
		const birthYear = birthYearMatch ? Number(birthYearMatch[1]) : null;
		const identified = /paciente identificado|consultante|caso índice|caso indice/.test(lower);
		let m;
		const meLlamo = sentence.match(new RegExp(`(?:me\\s+llamo|soy)\\s+(${NAME})(?:\\s+${AGE})?`, "u"));
		if (meLlamo && !/soy\s+hij/i.test(sentence)) nameSelf(b, cleanName(meLlamo[1]), {
			gender: genderFromWord(sentence),
			age: meLlamo[2] ? Number(meLlamo[2]) : ageNear(sentence, cleanName(meLlamo[1]))
		});
		const estoyCasad = sentence.match(new RegExp(`estoy\\s+casad([oa])\\s+con\\s+(${NAME})(?:\\s+${AGE})?`, "u"));
		if (estoyCasad) {
			const g = estoyCasad[1] === "a" ? "female" : "male";
			addRel(b, "marriage", ensureSelf(b, { gender: g }), getOrCreate(b, cleanName(estoyCasad[2]), {
				gender: g === "female" ? "male" : "female",
				age: estoyCasad[3] ? Number(estoyCasad[3]) : null
			}));
		}
		const meCase = sentence.match(new RegExp(`me\\s+cas[eé]\\s+con\\s+(${NAME})(?:\\s+${AGE})?`, "u"));
		if (meCase) addRel(b, "marriage", ensureSelf(b, { gender: genderFromWord(sentence) }), getOrCreate(b, cleanName(meCase[1]), { age: meCase[2] ? Number(meCase[2]) : null }));
		const misPadres = sentence.match(new RegExp(`mis\\s+padres\\s+(?:se\\s+llaman?|son)\\s+(${NAME})\\s+(?:y|e)\\s+(${NAME})`, "u"));
		if (misPadres) {
			const self = ensureSelf(b);
			const p1 = getOrCreate(b, cleanName(misPadres[1]));
			const p2 = getOrCreate(b, cleanName(misPadres[2]));
			addRel(b, "parent_child", p1, self);
			addRel(b, "parent_child", p2, self);
			addRel(b, "marriage", p1, p2);
		}
		const miPariente = sentence.match(new RegExp(`mi\\s+(padre|madre|hermano|hermana|esposo|esposa|marido|mujer|exesposo|exesposa)\\s+(?:se\\s+llama|es)\\s+(${NAME})(?:\\s+${AGE})?`, "u"));
		if (miPariente) {
			const role = miPariente[1].toLowerCase();
			const g = genderFromWord(role);
			const other = getOrCreate(b, cleanName(miPariente[2]), {
				gender: g,
				age: miPariente[3] ? Number(miPariente[3]) : null
			});
			const self = ensureSelf(b, { gender: null });
			if (role === "padre" || role === "madre") addRel(b, "parent_child", other, self);
			else if (role === "hermano" || role === "hermana") addRel(b, "sibling", self, other);
			else if (role === "exesposo" || role === "exesposa") addRel(b, "divorce", self, other);
			else addRel(b, "marriage", self, other);
		}
		const marriageRe = new RegExp(`(${NAME})(?:\\s+${AGE})?\\s+(?:est[aá]\\s+)?casad([oa])\\s+con\\s+(${NAME})(?:\\s+${AGE})?`, "u");
		const marriageRe2 = new RegExp(`(${NAME})\\s+(?:y|e)\\s+(${NAME})\\s+(?:est[aá]n\\s+)?casad[oa]s`, "u");
		const spouseRe = new RegExp(`(${NAME})\\s+(?:es\\s+)?(?:el\\s+|la\\s+)?(esposo|esposa|marido|mujer|exesposo|exesposa)\\s+de\\s+(${NAME})`, "u");
		const cohabRe = new RegExp(`(${NAME})(?:\\s+${AGE})?\\s+(?:vive|convive)\\s+con\\s+(${NAME})`, "u");
		const widowRe = new RegExp(`(${NAME})\\s+(?:es\\s+|está\\s+)?viud([oa])\\s+de\\s+(${NAME})`, "u");
		if (m = sentence.match(marriageRe)) {
			const g1 = m[3] === "a" ? "female" : m[3] === "o" ? "male" : "unknown";
			const g2 = g1 === "female" ? "male" : g1 === "male" ? "female" : "unknown";
			const n1 = cleanName(m[1]);
			const n2 = cleanName(m[4]);
			addRel(b, "marriage", getOrCreate(b, n1, {
				gender: g1,
				age: m[2] ? Number(m[2]) : ageNear(sentence, n1)
			}), getOrCreate(b, n2, {
				gender: g2,
				age: m[5] ? Number(m[5]) : ageNear(sentence, n2)
			}));
		} else if (m = sentence.match(marriageRe2)) addRel(b, "marriage", getOrCreate(b, cleanName(m[1])), getOrCreate(b, cleanName(m[2])));
		else if (m = sentence.match(spouseRe)) {
			const n1 = cleanName(m[1]);
			const n2 = cleanName(m[3]);
			const g = genderFromWord(m[2]);
			addRel(b, /ex/.test(m[2].toLowerCase()) ? "divorce" : "marriage", getOrCreate(b, n1, { gender: g }), getOrCreate(b, n2, { gender: g === "male" ? "female" : g === "female" ? "male" : "unknown" }));
		} else if (m = sentence.match(widowRe)) {
			const n1 = cleanName(m[1]);
			const n2 = cleanName(m[3]);
			addRel(b, "marriage", getOrCreate(b, n1, { gender: m[2] === "a" ? "female" : "male" }), getOrCreate(b, n2, { deceased: true }));
		} else if (m = sentence.match(cohabRe)) {
			const n1 = cleanName(m[1]);
			const n2 = cleanName(m[3]);
			addRel(b, "cohabitation", getOrCreate(b, n1, { age: m[2] ? Number(m[2]) : null }), getOrCreate(b, n2));
		}
		const divRe = new RegExp(`(${NAME})\\s+(?:est[aá]\\s+)?divorciad([oa])\\s+de\\s+(${NAME})`, "u");
		const divRe2 = new RegExp(`(${NAME})\\s+(?:y|e)\\s+(${NAME})\\s+(?:est[aá]n\\s+)?(?:divorciad[oa]s|separad[oa]s)`, "u");
		const sepRe = new RegExp(`(${NAME})\\s+se\\s+separ[oó]\\s+de\\s+(${NAME})`, "u");
		if (m = sentence.match(divRe)) {
			const n1 = cleanName(m[1]);
			const n2 = cleanName(m[3]);
			addRel(b, "divorce", getOrCreate(b, n1, { gender: m[2] === "a" ? "female" : "male" }), getOrCreate(b, n2));
		} else if (m = sentence.match(divRe2)) addRel(b, /separad/.test(lower) ? "separation" : "divorce", getOrCreate(b, cleanName(m[1])), getOrCreate(b, cleanName(m[2])));
		else if (m = sentence.match(sepRe)) addRel(b, "separation", getOrCreate(b, cleanName(m[1])), getOrCreate(b, cleanName(m[2])));
		const parentsRe = new RegExp(`padres?\\s+de\\s+(${NAME})\\s+(?:se\\s+llaman?|son|son\\s+llamados)\\s+(${NAME})\\s+(?:y|e)\\s+(${NAME})`, "u");
		const parentsOfRe = new RegExp(`(${NAME})\\s+(?:y|e)\\s+(${NAME})\\s+(?:son|fueron)\\s+(?:los\\s+)?padres\\s+de\\s+(${NAME})`, "u");
		const childOfRe = new RegExp(`(${NAME})\\s+(?:es|era)\\s+hij([oa])\\s+de\\s+(${NAME})(?:\\s+(?:y|e)\\s+(${NAME}))?`, "u");
		const fatherRe = new RegExp(`(?:el\\s+)?padre\\s+de\\s+(${NAME})\\s+(?:es|se\\s+llama)\\s+(${NAME})`, "u");
		const motherRe = new RegExp(`(?:la\\s+)?madre\\s+de\\s+(${NAME})\\s+(?:es|se\\s+llama)\\s+(${NAME})`, "u");
		const isFatherRe = new RegExp(`(${NAME})\\s+es\\s+(?:el\\s+)?padre\\s+de\\s+(${NAME})`, "u");
		const isMotherRe = new RegExp(`(${NAME})\\s+es\\s+(?:la\\s+)?madre\\s+de\\s+(${NAME})`, "u");
		const adoptedRe = new RegExp(`(${NAME})\\s+(?:fue\\s+)?adoptad([oa])\\s+por\\s+(${NAME})(?:\\s+(?:y|e)\\s+(${NAME}))?`, "u");
		if (m = sentence.match(parentsRe)) {
			const child = getOrCreate(b, cleanName(m[1]));
			const p1 = getOrCreate(b, cleanName(m[2]));
			const p2 = getOrCreate(b, cleanName(m[3]));
			addRel(b, "parent_child", p1, child);
			addRel(b, "parent_child", p2, child);
			addRel(b, "marriage", p1, p2);
		} else if (m = sentence.match(parentsOfRe)) {
			const p1 = getOrCreate(b, cleanName(m[1]));
			const p2 = getOrCreate(b, cleanName(m[2]));
			const child = getOrCreate(b, cleanName(m[3]));
			addRel(b, "parent_child", p1, child);
			addRel(b, "parent_child", p2, child);
			addRel(b, "marriage", p1, p2);
		} else if (m = sentence.match(childOfRe)) {
			const child = getOrCreate(b, cleanName(m[1]), { gender: m[2] === "a" ? "female" : "male" });
			const p1 = getOrCreate(b, cleanName(m[3]));
			addRel(b, "parent_child", p1, child);
			if (m[4]) {
				const p2 = getOrCreate(b, cleanName(m[4]));
				addRel(b, "parent_child", p2, child);
				addRel(b, "marriage", p1, p2);
			}
		} else if (m = sentence.match(isFatherRe)) addRel(b, "parent_child", getOrCreate(b, cleanName(m[1]), { gender: "male" }), getOrCreate(b, cleanName(m[2])));
		else if (m = sentence.match(isMotherRe)) addRel(b, "parent_child", getOrCreate(b, cleanName(m[1]), { gender: "female" }), getOrCreate(b, cleanName(m[2])));
		else if (m = sentence.match(fatherRe)) {
			const child = getOrCreate(b, cleanName(m[1]));
			addRel(b, "parent_child", getOrCreate(b, cleanName(m[2]), { gender: "male" }), child);
		} else if (m = sentence.match(motherRe)) {
			const child = getOrCreate(b, cleanName(m[1]));
			addRel(b, "parent_child", getOrCreate(b, cleanName(m[2]), { gender: "female" }), child);
		} else if (m = sentence.match(adoptedRe)) {
			const child = getOrCreate(b, cleanName(m[1]), { gender: m[2] === "a" ? "female" : "male" });
			const p1 = getOrCreate(b, cleanName(m[3]));
			addRel(b, "adopted", p1, child);
			if (m[4]) {
				const p2 = getOrCreate(b, cleanName(m[4]));
				addRel(b, "adopted", p2, child);
				addRel(b, "marriage", p1, p2);
			}
		}
		const grandparentsRe = new RegExp(`abuelos\\s+(maternos|paternos)?\\s*de\\s+(${NAME})\\s+(?:se\\s+llaman?|son)\\s+(${NAME})\\s+(?:y|e)\\s+(${NAME})`, "u");
		if (m = sentence.match(grandparentsRe)) {
			const child = getOrCreate(b, cleanName(m[2]));
			const g1 = getOrCreate(b, cleanName(m[3]));
			const g2 = getOrCreate(b, cleanName(m[4]));
			addRel(b, "marriage", g1, g2);
			const side = (m[1] ?? "").toLowerCase();
			const existingParents = parentsOf(b, child);
			let mid = null;
			if (side === "maternos") mid = existingParents.map((id) => b.persons.find((p) => p.id === id)).find((p) => p?.gender === "female")?.id ?? existingParents[0] ?? null;
			else if (side === "paternos") mid = existingParents.map((id) => b.persons.find((p) => p.id === id)).find((p) => p?.gender === "male")?.id ?? existingParents[0] ?? null;
			else mid = existingParents[0] ?? null;
			if (mid) {
				addRel(b, "parent_child", g1, mid);
				addRel(b, "parent_child", g2, mid);
			} else {
				addRel(b, "parent_child", g1, child);
				addRel(b, "parent_child", g2, child);
			}
		}
		const childrenRe = new RegExp(`(?:tienen|tiene|tuvieron|tuvo|tengo|tuve|tenemos|tuvimos)\\s+(?:un|una|uno|dos|tres|cuatro|cinco|seis|\\d+)?\\s*hijos?\\s*(?:llamad[oa]s?)?\\s*[:,]?\\s*(.+)`, "iu");
		const childrenRe2 = new RegExp(`(?:tienen|tiene|tuvieron|tuvo|tengo|tuve|tenemos|tuvimos)\\s+(?:un[oa]?\\s+)?hij([oa])\\s+(?:llamad[oa]\\s+)?(${NAME})`, "iu");
		if (m = sentence.match(childrenRe)) {
			const kids = parseNamedPeople(m[1]);
			if (kids.length > 0) {
				const parentIds = parentsForChildren(b, sentence, kids.map((k) => k.name));
				for (const kid of kids) {
					const cid = getOrCreate(b, kid.name, {
						age: kid.age,
						gender: kid.gender
					});
					for (const pid of parentIds) addRel(b, "parent_child", pid, cid);
				}
			}
		} else if (m = sentence.match(childrenRe2)) {
			const g = m[1] === "a" ? "female" : "male";
			const cid = getOrCreate(b, cleanName(m[2]), { gender: g });
			const parentIds = parentsForChildren(b, sentence, [cleanName(m[2])]);
			for (const pid of parentIds) addRel(b, "parent_child", pid, cid);
		}
		const sibRe = new RegExp(`(${NAME})\\s+tiene\\s+(?:una?|dos|tres|\\d+)?\\s*herman([oa])s?\\s+(?:llamad[oa]s?\\s+)?(?:[:,]?\\s*)(.+)`, "u");
		const sibRe2 = new RegExp(`(${NAME})(?:\\s*,\\s*(${NAME}))*\\s+(?:y|e)\\s+(${NAME})\\s+son\\s+herman[oa]s`, "u");
		const sibRe3 = new RegExp(`(${NAME})\\s+es\\s+herman([oa])\\s+de\\s+(${NAME})`, "u");
		const tengoHermano = sentence.match(new RegExp(`tengo\\s+(?:una?|dos|tres|\\d+)?\\s*herman([oa])s?\\s+(?:llamad[oa]s?\\s+)?(?:[:,]?\\s*)(.+)`, "u"));
		if (m = sentence.match(sibRe2)) {
			const ids = [
				m[1],
				m[2],
				m[3]
			].filter(Boolean).map(cleanName).map((n) => getOrCreate(b, n));
			for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) addRel(b, "sibling", ids[i], ids[j]);
		} else if (m = sentence.match(sibRe3)) {
			const g = m[2] === "a" ? "female" : "male";
			addRel(b, "sibling", getOrCreate(b, cleanName(m[1]), { gender: g }), getOrCreate(b, cleanName(m[3])));
		} else if (tengoHermano) {
			const self = ensureSelf(b);
			const g2 = tengoHermano[1] === "a" ? "female" : "male";
			const others = parseNamedPeople(tengoHermano[2]);
			const list = others.length ? others : [{
				name: cleanName(tengoHermano[2]),
				age: null,
				gender: g2
			}];
			for (const other of list) {
				if (!other.name) continue;
				addRel(b, "sibling", self, getOrCreate(b, other.name, {
					gender: other.gender ?? g2,
					age: other.age
				}));
			}
		} else if (m = sentence.match(sibRe)) {
			const id1 = getOrCreate(b, cleanName(m[1]));
			const g2 = m[2] === "a" ? "female" : "male";
			const others = parseNamedPeople(m[3]);
			if (others.length === 0) {
				const single = cleanName(m[3]);
				if (single) addRel(b, "sibling", id1, getOrCreate(b, single, { gender: g2 }));
			} else for (const other of others) addRel(b, "sibling", id1, getOrCreate(b, other.name, {
				gender: other.gender ?? g2,
				age: other.age
			}));
		}
		const conflictRe = new RegExp(`(${NAME})\\s+(?:y|e)\\s+(${NAME})\\s+(?:tienen|hay|mantienen)\\s+(?:un\\s+)?conflicto`, "u");
		const closeRe = new RegExp(`(${NAME})\\s+(?:es|est[aá])\\s+muy\\s+cercan[oa]\\s+(?:a|con)\\s+(${NAME})`, "u");
		const distantRe = new RegExp(`(${NAME})\\s+(?:y|e)\\s+(${NAME})\\s+(?:est[aá]n|tienen una relación)\\s+distantes?`, "u");
		const cutoffRe = new RegExp(`(${NAME})\\s+(?:cort[oó]|rompi[oó])\\s+(?:la\\s+)?relaci[oó]n\\s+con\\s+(${NAME})`, "u");
		if (m = sentence.match(conflictRe)) addRel(b, "conflict", getOrCreate(b, cleanName(m[1])), getOrCreate(b, cleanName(m[2])));
		if (m = sentence.match(closeRe)) addRel(b, "close", getOrCreate(b, cleanName(m[1])), getOrCreate(b, cleanName(m[2])));
		if (m = sentence.match(distantRe)) addRel(b, "distant", getOrCreate(b, cleanName(m[1])), getOrCreate(b, cleanName(m[2])));
		if (m = sentence.match(cutoffRe)) addRel(b, "cutoff", getOrCreate(b, cleanName(m[1])), getOrCreate(b, cleanName(m[2])));
		const simple = sentence.matchAll(new RegExp(`(${NAME})\\s+${AGE}`, "gu"));
		for (const sm of simple) {
			const name = cleanName(sm[1]);
			if (!name) continue;
			getOrCreate(b, name, {
				age: Number(sm[2]),
				deceased,
				deathYear,
				birthYear,
				identifiedPatient: identified
			});
		}
		if (deceased) {
			const names = sentence.match(new RegExp(NAME, "gu")) ?? [];
			for (const n of names) {
				const name = cleanName(n);
				if (!name) continue;
				getOrCreate(b, name, {
					deceased: true,
					deathYear
				});
			}
		}
		if (identified) {
			const names = sentence.match(new RegExp(NAME, "gu")) ?? [];
			for (const n of names) {
				const name = cleanName(n);
				if (!name) continue;
				getOrCreate(b, name, { identifiedPatient: true });
			}
		}
		if (birthYear) {
			const names = sentence.match(new RegExp(NAME, "gu")) ?? [];
			for (const n of names) {
				const name = cleanName(n);
				if (!name) continue;
				getOrCreate(b, name, { birthYear });
			}
		}
	}
	for (const r of [...b.relationships]) {
		if (r.type !== "sibling") continue;
		const pa = parentsOf(b, r.a);
		const pb = parentsOf(b, r.b);
		if (pa.length && !pb.length) for (const p of pa) addRel(b, "parent_child", p, r.b);
		else if (pb.length && !pa.length) for (const p of pb) addRel(b, "parent_child", p, r.a);
	}
	const parentsByChild = /* @__PURE__ */ new Map();
	for (const r of b.relationships) {
		if (!PARENT_TYPES.includes(r.type)) continue;
		parentsByChild.set(r.b, [...parentsByChild.get(r.b) ?? [], r.a]);
	}
	for (const ps of parentsByChild.values()) {
		const unique = [...new Set(ps)];
		if (unique.length !== 2) continue;
		if (!b.relationships.some((r) => UNION_TYPES.includes(r.type) && (r.a === unique[0] && r.b === unique[1] || r.a === unique[1] && r.b === unique[0]))) addRel(b, "marriage", unique[0], unique[1]);
	}
	return {
		persons: b.persons,
		relationships: b.relationships
	};
}
var STORAGE_KEY = "genograma.v2";
function snap(s) {
	return {
		persons: s.persons.map((p) => ({ ...p })),
		relationships: s.relationships.map((r) => ({ ...r }))
	};
}
function nextIds(persons, relationships) {
	const maxP = persons.reduce((m, p) => Math.max(m, Number(p.id.replace(/\D/g, "")) || 0), 0);
	const maxR = relationships.reduce((m, r) => Math.max(m, Number(r.id.replace(/\D/g, "")) || 0), 0);
	return {
		p: maxP + 1,
		r: maxR + 1
	};
}
function sanitize(data) {
	const persons = (data.persons ?? []).map((p, i) => emptyPerson({
		...p,
		id: p.id || `p${i + 1}`,
		name: String(p.name ?? "").trim()
	})).filter((p) => p.name);
	const ids = new Set(persons.map((p) => p.id));
	return {
		persons,
		relationships: (data.relationships ?? []).filter((r) => r && ids.has(r.a) && ids.has(r.b) && r.a !== r.b && r.type)
	};
}
var DEMO = `María de 45 años está casada con Juan de 48.
Tienen dos hijos: Laura de 15 y Pedro de 12.
Los padres de María se llaman Carmen y José.
José falleció en 2018.
María tiene una hermana llamada Ana.`;
var useGenogram = create((set, get) => ({
	persons: [],
	relationships: [],
	selectedId: null,
	status: "Listo.",
	hydrated: false,
	epoch: 0,
	layoutEpoch: 0,
	sidebarTab: "texto",
	panel: "lienzo",
	past: [],
	future: [],
	hydrate: () => {
		if (get().hydrated) return;
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				if (Array.isArray(parsed.persons) && parsed.persons.length > 0) {
					const clean = sanitize({
						persons: parsed.persons,
						relationships: parsed.relationships ?? []
					});
					set({
						persons: clean.persons,
						relationships: clean.relationships,
						hydrated: true,
						epoch: 1,
						layoutEpoch: 1,
						status: "Documento restaurado."
					});
					return;
				}
			}
		} catch {}
		const parsed = parseFamilyText(DEMO);
		set({
			persons: autoLayout(parsed.persons, parsed.relationships),
			relationships: parsed.relationships,
			hydrated: true,
			epoch: 1,
			layoutEpoch: 1,
			status: "Ejemplo cargado. Edítalo o pega tu propia familia."
		});
		get().persist();
	},
	persist: () => {
		const { persons, relationships } = get();
		try {
			localStorage.setItem(STORAGE_KEY, JSON.stringify({
				persons,
				relationships
			}));
		} catch {}
	},
	checkpoint: () => {
		const { persons, relationships, past } = get();
		set({
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			future: []
		});
	},
	undo: () => {
		const { past, persons, relationships, future } = get();
		const prev = past[past.length - 1];
		if (!prev) return;
		set({
			past: past.slice(0, -1),
			future: [snap({
				persons,
				relationships
			}), ...future].slice(0, 40),
			persons: prev.persons,
			relationships: prev.relationships,
			epoch: get().epoch + 1,
			layoutEpoch: get().layoutEpoch + 1,
			status: "Deshecho."
		});
		get().persist();
	},
	redo: () => {
		const { future, persons, relationships, past } = get();
		const next = future[0];
		if (!next) return;
		set({
			future: future.slice(1),
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			persons: next.persons,
			relationships: next.relationships,
			epoch: get().epoch + 1,
			layoutEpoch: get().layoutEpoch + 1,
			status: "Rehecho."
		});
		get().persist();
	},
	select: (id) => set({
		selectedId: id,
		sidebarTab: id ? "personas" : get().sidebarTab
	}),
	setSidebarTab: (tab) => set({ sidebarTab: tab }),
	setPanel: (panel) => set({ panel }),
	loadFromText: (text) => {
		const parsed = parseFamilyText(text);
		if (parsed.persons.length === 0) {
			set({ status: "No se detectaron personas. Usa nombres propios y frases como «casada con», «hijos», «padres»." });
			return {
				ok: false,
				message: get().status
			};
		}
		get().loadData(parsed, `Generado: ${parsed.persons.length} personas, ${parsed.relationships.length} vínculos.`);
		return {
			ok: true,
			message: get().status
		};
	},
	loadData: (data, status) => {
		const { persons, relationships, past } = get();
		const clean = sanitize(data);
		const laid = autoLayout(clean.persons, clean.relationships);
		set({
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			future: [],
			persons: laid,
			relationships: clean.relationships,
			selectedId: null,
			status,
			epoch: get().epoch + 1,
			layoutEpoch: get().layoutEpoch + 1,
			panel: "lienzo"
		});
		get().persist();
	},
	addPerson: (input) => {
		const name = input.name.trim();
		if (!name) {
			set({ status: "Escribe un nombre." });
			return null;
		}
		const { persons, relationships, past, selectedId } = get();
		const { p } = nextIds(persons, relationships);
		const id = `p${p}`;
		const selected = persons.find((x) => x.id === selectedId);
		const maxX = persons.reduce((m, person) => Math.max(m, person.x), 90);
		const person = emptyPerson({
			id,
			name,
			gender: input.gender,
			age: input.age,
			deceased: input.deceased,
			identifiedPatient: Boolean(input.identifiedPatient),
			occupation: input.occupation ?? "",
			notes: input.notes ?? "",
			birthYear: input.birthYear ?? null,
			deathYear: input.deathYear ?? null,
			x: input.x ?? (selected ? selected.x + 110 : maxX + 110),
			y: input.y ?? (selected ? selected.y : persons[0]?.y ?? 90),
			generation: selected?.generation ?? 0
		});
		set({
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			future: [],
			persons: [...persons, person],
			selectedId: id,
			sidebarTab: "personas",
			status: `Añadido: ${name}`,
			epoch: get().epoch + 1,
			panel: "lienzo"
		});
		get().persist();
		return id;
	},
	updatePerson: (id, patch, opts) => {
		const { persons, relationships, past } = get();
		const history = opts?.history !== false;
		set({
			past: history ? [...past, snap({
				persons,
				relationships
			})].slice(-40) : past,
			future: history ? [] : get().future,
			persons: persons.map((p) => p.id === id ? {
				...p,
				...patch
			} : p)
		});
		get().persist();
	},
	removePerson: (id) => {
		const { persons, relationships, past } = get();
		set({
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			future: [],
			persons: persons.filter((p) => p.id !== id),
			relationships: relationships.filter((r) => r.a !== id && r.b !== id),
			selectedId: get().selectedId === id ? null : get().selectedId,
			status: "Persona eliminada.",
			epoch: get().epoch + 1
		});
		get().persist();
	},
	addRelationship: (type, a, b) => {
		if (!a || !b || a === b) {
			set({ status: "Selecciona dos personas distintas." });
			return;
		}
		const { persons, relationships, past } = get();
		const { r } = nextIds(persons, relationships);
		const nextRels = [...relationships, {
			id: `r${r}`,
			type,
			a,
			b
		}];
		set({
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			future: [],
			relationships: nextRels,
			persons: autoLayout(persons, nextRels),
			status: "Vínculo creado.",
			epoch: get().epoch + 1,
			layoutEpoch: get().layoutEpoch + 1,
			panel: "lienzo"
		});
		get().persist();
	},
	removeRelationship: (id) => {
		const { persons, relationships, past } = get();
		set({
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			future: [],
			relationships: relationships.filter((r) => r.id !== id),
			status: "Vínculo eliminado."
		});
		get().persist();
	},
	movePerson: (id, x, y) => {
		set({ persons: get().persons.map((p) => p.id === id ? {
			...p,
			x,
			y
		} : p) });
	},
	layout: () => {
		const { persons, relationships, past } = get();
		set({
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			future: [],
			persons: autoLayout(persons, relationships),
			status: "Organizado por generaciones.",
			epoch: get().epoch + 1,
			layoutEpoch: get().layoutEpoch + 1
		});
		get().persist();
	},
	clear: () => {
		const { persons, relationships, past } = get();
		set({
			past: [...past, snap({
				persons,
				relationships
			})].slice(-40),
			future: [],
			persons: [],
			relationships: [],
			selectedId: null,
			status: "Lienzo vacío. Pega un texto o añade personas.",
			epoch: get().epoch + 1,
			layoutEpoch: get().layoutEpoch + 1
		});
		get().persist();
	}
}));
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/35 disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
var INK = "#1c2128";
var MUTED = "#6a717a";
var MALE = "#e2e8ee";
var FEMALE = "#ece7e2";
var UNKNOWN = "#e6e4df";
var DECEASED = "#d5d3ce";
var ACCENT = "#1e2329";
var HALF = 18;
var LINK_TYPES = [
	"marriage",
	"cohabitation",
	"separation",
	"divorce",
	"parent_child",
	"adopted",
	"sibling",
	"close",
	"distant",
	"cutoff",
	"conflict"
];
function fillOf(p) {
	if (p.deceased) return DECEASED;
	if (p.gender === "female") return FEMALE;
	if (p.gender === "male") return MALE;
	return UNKNOWN;
}
function zigzag(x1, y1, x2, y2, amp = 6) {
	const dx = x2 - x1;
	const dy = y2 - y1;
	const len = Math.hypot(dx, dy) || 1;
	const nx = -dy / len;
	const ny = dx / len;
	const steps = Math.max(7, Math.round(len / 11));
	let d = `M ${x1} ${y1}`;
	for (let i = 1; i <= steps; i++) {
		const t = i / steps;
		const sign = i % 2 === 0 ? 1 : -1;
		const last = i === steps;
		d += ` L ${x1 + dx * t + (last ? 0 : nx * amp * sign)} ${y1 + dy * t + (last ? 0 : ny * amp * sign)}`;
	}
	return d;
}
function RelLayer({ persons, relationships }) {
	const byId = (0, import_react.useMemo)(() => new Map(persons.map((p) => [p.id, p])), [persons]);
	const nodes = [];
	const covered = /* @__PURE__ */ new Set();
	function parentKey(id) {
		return relationships.filter((rel) => PARENT_TYPES.includes(rel.type) && rel.b === id).map((rel) => rel.a).sort().join("|");
	}
	for (const r of relationships) {
		if (!UNION_TYPES.includes(r.type)) continue;
		const a = byId.get(r.a);
		const b = byId.get(r.b);
		if (!a || !b) continue;
		const left = a.x <= b.x ? a : b;
		const right = a.x <= b.x ? b : a;
		const y = (left.y + right.y) / 2;
		const x1 = left.x + HALF + 2;
		const x2 = right.x - HALF - 2;
		const midX = (left.x + right.x) / 2;
		const dashed = r.type === "cohabitation";
		const double = r.type === "marriage" || r.type === "divorce" || r.type === "separation";
		const sepDash = r.type === "separation" ? "5 4" : dashed ? "7 5" : void 0;
		nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1,
				y1: y - (double ? 2.5 : 0),
				x2,
				y2: y - (double ? 2.5 : 0),
				stroke: INK,
				strokeWidth: 2,
				strokeDasharray: sepDash
			}),
			double ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1,
				y1: y + 2.5,
				x2,
				y2: y + 2.5,
				stroke: INK,
				strokeWidth: 2,
				strokeDasharray: r.type === "separation" ? "5 4" : void 0
			}) : null,
			r.type === "divorce" || r.type === "separation" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: midX - 7,
				y1: y - 10,
				x2: midX + 1,
				y2: y + 10,
				stroke: INK,
				strokeWidth: 2
			}), r.type === "divorce" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: midX - 1,
				y1: y - 10,
				x2: midX + 7,
				y2: y + 10,
				stroke: INK,
				strokeWidth: 2
			}) : null] }) : null
		] }, r.id));
		const kids = persons.filter((p) => {
			const parents = relationships.filter((rel) => PARENT_TYPES.includes(rel.type) && rel.b === p.id).map((rel) => rel.a);
			return parents.includes(a.id) && parents.includes(b.id);
		});
		if (kids.length === 0) continue;
		const barY = Math.min(...kids.map((k) => k.y)) - 50;
		const xs = kids.map((k) => k.x);
		const minX = Math.min(...xs, midX);
		const maxX = Math.max(...xs, midX);
		nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: `M ${midX} ${y + 6} L ${midX} ${barY} M ${minX} ${barY} L ${maxX} ${barY}`,
			fill: "none",
			stroke: INK,
			strokeWidth: 1.6
		}), kids.map((k) => {
			covered.add(k.id);
			const adopted = relationships.some((rel) => rel.type === "adopted" && rel.b === k.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: k.x,
				y1: barY,
				x2: k.x,
				y2: k.y - HALF - 2,
				stroke: INK,
				strokeWidth: 1.6,
				strokeDasharray: adopted ? "5 4" : void 0
			}, k.id);
		})] }, `${r.id}-kids`));
	}
	const leftovers = /* @__PURE__ */ new Map();
	for (const p of persons) {
		if (covered.has(p.id)) continue;
		const parents = relationships.filter((rel) => PARENT_TYPES.includes(rel.type) && rel.b === p.id).map((rel) => rel.a).sort();
		if (parents.length === 0) continue;
		const key = parents.join("|");
		const arr = leftovers.get(key) ?? [];
		arr.push(p);
		leftovers.set(key, arr);
	}
	leftovers.forEach((kids, key) => {
		const parents = key.split("|").map((id) => byId.get(id)).filter((p) => Boolean(p));
		if (!parents.length) return;
		const midX = parents.reduce((s, p) => s + p.x, 0) / parents.length;
		const midY = parents.reduce((s, p) => s + p.y, 0) / parents.length;
		const barY = Math.min(...kids.map((k) => k.y)) - 50;
		const xs = kids.map((k) => k.x);
		const minX = Math.min(...xs, midX);
		const maxX = Math.max(...xs, midX);
		nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: `M ${midX} ${midY + HALF + 2} L ${midX} ${barY} M ${minX} ${barY} L ${maxX} ${barY}`,
			fill: "none",
			stroke: INK,
			strokeWidth: 1.6
		}), kids.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: k.x,
			y1: barY,
			x2: k.x,
			y2: k.y - HALF - 2,
			stroke: INK,
			strokeWidth: 1.6,
			strokeDasharray: relationships.some((rel) => rel.type === "adopted" && rel.b === k.id) ? "5 4" : void 0
		}, k.id))] }, `solo-${key}`));
	});
	for (const r of relationships) {
		if (r.type !== "sibling") continue;
		const a = byId.get(r.a);
		const b = byId.get(r.b);
		if (!a || !b) continue;
		const ka = parentKey(a.id);
		const kb = parentKey(b.id);
		if (ka && ka === kb) continue;
		const barY = Math.min(a.y, b.y) - 40;
		nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: `M ${a.x} ${a.y - HALF} L ${a.x} ${barY} L ${b.x} ${barY} L ${b.x} ${b.y - HALF}`,
			fill: "none",
			stroke: MUTED,
			strokeWidth: 1.3
		}, r.id));
	}
	for (const r of relationships) {
		if (![
			"close",
			"distant",
			"cutoff",
			"conflict"
		].includes(r.type)) continue;
		const a = byId.get(r.a);
		const b = byId.get(r.b);
		if (!a || !b) continue;
		const dx = b.x - a.x;
		const dy = b.y - a.y;
		const len = Math.hypot(dx, dy) || 1;
		const ox = -dy / len * 10;
		const oy = dx / len * 10;
		const x1 = a.x + ox;
		const y1 = a.y + oy;
		const x2 = b.x + ox;
		const y2 = b.y + oy;
		if (r.type === "conflict") nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: zigzag(x1, y1, x2, y2),
			fill: "none",
			stroke: INK,
			strokeWidth: 1.6
		}, r.id));
		else if (r.type === "distant") nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1,
			y1,
			x2,
			y2,
			stroke: INK,
			strokeWidth: 1.4,
			strokeDasharray: "3 5"
		}, r.id));
		else if (r.type === "close") nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1,
				y1: y1 - 3,
				x2,
				y2: y2 - 3,
				stroke: INK,
				strokeWidth: 1.4
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1,
				y1,
				x2,
				y2,
				stroke: INK,
				strokeWidth: 1.4
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1,
				y1: y1 + 3,
				x2,
				y2: y2 + 3,
				stroke: INK,
				strokeWidth: 1.4
			})
		] }, r.id));
		else {
			const mx = (x1 + x2) / 2;
			const my = (y1 + y2) / 2;
			nodes.push(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1,
					y1,
					x2: mx - 8,
					y2: my - 2,
					stroke: INK,
					strokeWidth: 1.5
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: mx + 8,
					y1: my + 2,
					x2,
					y2,
					stroke: INK,
					strokeWidth: 1.5
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: mx - 6,
					y1: my - 8,
					x2: mx - 2,
					y2: my + 8,
					stroke: INK,
					strokeWidth: 1.6
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: mx + 2,
					y1: my - 8,
					x2: mx + 6,
					y2: my + 8,
					stroke: INK,
					strokeWidth: 1.6
				})
			] }, r.id));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", { children: nodes });
}
function PersonMark({ person, selected, linking, onPointerDown }) {
	const fill = fillOf(person);
	const stroke = linking ? ACCENT : selected ? ACCENT : INK;
	const sw = linking || selected ? 2.6 : 2;
	const years = personYears(person);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
		transform: `translate(${person.x} ${person.y})`,
		onPointerDown,
		style: { cursor: linking ? "pointer" : "grab" },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: -30,
				y: -30,
				width: 60,
				height: 78,
				fill: "transparent"
			}),
			person.identifiedPatient ? person.gender === "female" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				r: 23,
				fill: "none",
				stroke,
				strokeWidth: 1.4
			}) : person.gender === "unknown" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: `0,-24 24,22 -24,22`,
				fill: "none",
				stroke
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: -23,
				y: -23,
				width: 46,
				height: 46,
				fill: "none",
				stroke,
				strokeWidth: 1.4
			}) : null,
			person.gender === "female" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				r: HALF,
				fill,
				stroke,
				strokeWidth: sw
			}) : person.gender === "unknown" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: `0,-20 19,17 -19,17`,
				fill,
				stroke,
				strokeWidth: sw
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: -18,
				y: -18,
				width: 36,
				height: 36,
				fill,
				stroke,
				strokeWidth: sw
			}),
			person.deceased ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: -12,
				y1: -12,
				x2: 12,
				y2: 12,
				stroke: MUTED,
				strokeWidth: 2
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: 12,
				y1: -12,
				x2: -12,
				y2: 12,
				stroke: MUTED,
				strokeWidth: 2
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				y: 34,
				textAnchor: "middle",
				fontSize: 13,
				fontWeight: 600,
				fill: INK,
				fontFamily: "IBM Plex Sans, Segoe UI, sans-serif",
				children: person.name
			}),
			years ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				y: 49,
				textAnchor: "middle",
				fontSize: 11,
				fill: MUTED,
				fontFamily: "IBM Plex Sans, Segoe UI, sans-serif",
				children: years
			}) : null,
			person.occupation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				y: HALF + (years ? 44 : 31),
				textAnchor: "middle",
				fontSize: 10,
				fill: MUTED,
				fontStyle: "italic",
				fontFamily: "IBM Plex Sans, Segoe UI, sans-serif",
				children: person.occupation
			}) : null
		]
	});
}
function GenogramCanvas({ svgRef }) {
	const persons = useGenogram((s) => s.persons);
	const relationships = useGenogram((s) => s.relationships);
	const selectedId = useGenogram((s) => s.selectedId);
	const select = useGenogram((s) => s.select);
	const movePerson = useGenogram((s) => s.movePerson);
	const checkpoint = useGenogram((s) => s.checkpoint);
	const persist = useGenogram((s) => s.persist);
	const addPerson = useGenogram((s) => s.addPerson);
	const addRelationship = useGenogram((s) => s.addRelationship);
	const layoutEpoch = useGenogram((s) => s.layoutEpoch);
	const wrapRef = (0, import_react.useRef)(null);
	const [view, setView] = (0, import_react.useState)({
		x: 40,
		y: 30,
		k: 1
	});
	const viewRef = (0, import_react.useRef)(view);
	viewRef.current = view;
	const [tool, setTool] = (0, import_react.useState)("select");
	const [linkFrom, setLinkFrom] = (0, import_react.useState)(null);
	const [linkMenu, setLinkMenu] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const draftNameRef = (0, import_react.useRef)(null);
	const drag = (0, import_react.useRef)(null);
	const toWorld = (clientX, clientY) => {
		const svg = svgRef.current;
		const current = viewRef.current;
		if (!svg) return {
			x: 0,
			y: 0
		};
		const rect = svg.getBoundingClientRect();
		return {
			x: (clientX - rect.left - current.x) / current.k,
			y: (clientY - rect.top - current.y) / current.k
		};
	};
	const fit = () => {
		const el = wrapRef.current;
		if (!el || persons.length === 0) return;
		const w = el.clientWidth;
		const h = el.clientHeight;
		if (w < 40 || h < 40) return;
		let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
		for (const p of persons) {
			minX = Math.min(minX, p.x - 36);
			maxX = Math.max(maxX, p.x + 36);
			minY = Math.min(minY, p.y - 28);
			maxY = Math.max(maxY, p.y + 58);
		}
		const toolW = 56;
		const pad = 16;
		const availW = Math.max(80, w - 32 - toolW);
		const availH = Math.max(80, h - 32);
		const bw = Math.max(80, maxX - minX);
		const bh = Math.max(80, maxY - minY);
		const k = Math.min(availW / bw, availH / bh, 1.6);
		setView({
			k,
			x: pad + availW / 2 - (minX + maxX) / 2 * k,
			y: pad + availH / 2 - (minY + maxY) / 2 * k
		});
	};
	(0, import_react.useEffect)(() => {
		fit();
	}, [layoutEpoch]);
	(0, import_react.useEffect)(() => {
		const el = wrapRef.current;
		if (!el || typeof ResizeObserver === "undefined") return;
		let ready = false;
		const ro = new ResizeObserver(() => {
			if (!ready) {
				ready = true;
				fit();
			}
		});
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		const svg = svgRef.current;
		if (!svg) return;
		const onWheelNative = (e) => {
			e.preventDefault();
			const current = viewRef.current;
			const factor = e.deltaY > 0 ? .92 : 1.08;
			const nk = Math.min(2.6, Math.max(.35, current.k * factor));
			const rect = svg.getBoundingClientRect();
			const sx = e.clientX - rect.left;
			const sy = e.clientY - rect.top;
			const wx = (sx - current.x) / current.k;
			const wy = (sy - current.y) / current.k;
			setView({
				k: nk,
				x: sx - wx * nk,
				y: sy - wy * nk
			});
		};
		svg.addEventListener("wheel", onWheelNative, { passive: false });
		return () => svg.removeEventListener("wheel", onWheelNative);
	}, [svgRef]);
	(0, import_react.useEffect)(() => {
		if (draft) draftNameRef.current?.focus();
	}, [draft]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (e.key !== "Escape") return;
			setDraft(null);
			setLinkMenu(null);
			setLinkFrom(null);
			setTool("select");
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const zoomBy = (factor) => {
		const el = wrapRef.current;
		const current = viewRef.current;
		const nk = Math.min(2.6, Math.max(.35, current.k * factor));
		if (!el) {
			setView({
				...current,
				k: nk
			});
			return;
		}
		const sx = el.clientWidth / 2;
		const sy = el.clientHeight / 2;
		const wx = (sx - current.x) / current.k;
		const wy = (sy - current.y) / current.k;
		setView({
			k: nk,
			x: sx - wx * nk,
			y: sy - wy * nk
		});
	};
	const placeDraft = (clientX, clientY) => {
		const w = toWorld(clientX, clientY);
		setDraft({
			x: w.x,
			y: w.y,
			name: "",
			gender: "female"
		});
		setLinkMenu(null);
	};
	const confirmDraft = () => {
		if (!draft) return;
		if (addPerson({
			name: draft.name,
			gender: draft.gender,
			age: null,
			deceased: false,
			x: draft.x,
			y: draft.y
		})) setDraft(null);
	};
	const onPointerDownBg = (e) => {
		if (e.button !== 0) return;
		if (draft || linkMenu) {
			setDraft(null);
			setLinkMenu(null);
			return;
		}
		if (tool === "add") {
			placeDraft(e.clientX, e.clientY);
			return;
		}
		svgRef.current?.setPointerCapture(e.pointerId);
		const current = viewRef.current;
		drag.current = {
			kind: "pan",
			sx: e.clientX,
			sy: e.clientY,
			vx: current.x,
			vy: current.y,
			px: 0,
			py: 0,
			moved: false
		};
		select(null);
	};
	const onPointerDownPerson = (e, person) => {
		e.stopPropagation();
		if (tool === "add") {
			placeDraft(e.clientX, e.clientY);
			return;
		}
		if (tool === "link") {
			if (!linkFrom || linkFrom === person.id) {
				setLinkFrom(person.id);
				select(person.id);
			} else {
				setLinkMenu({
					a: linkFrom,
					b: person.id
				});
				setLinkFrom(null);
			}
			return;
		}
		svgRef.current?.setPointerCapture(e.pointerId);
		select(person.id);
		checkpoint();
		const current = viewRef.current;
		drag.current = {
			kind: "person",
			id: person.id,
			sx: e.clientX,
			sy: e.clientY,
			vx: current.x,
			vy: current.y,
			px: person.x,
			py: person.y,
			moved: false
		};
	};
	const onPointerMove = (e) => {
		const d = drag.current;
		if (!d) return;
		const dx = e.clientX - d.sx;
		const dy = e.clientY - d.sy;
		if (Math.hypot(dx, dy) > 3) d.moved = true;
		if (d.kind === "pan") setView({
			k: viewRef.current.k,
			x: d.vx + dx,
			y: d.vy + dy
		});
		else if (d.id) movePerson(d.id, d.px + dx / viewRef.current.k, d.py + dy / viewRef.current.k);
	};
	const onPointerUp = () => {
		if (drag.current?.kind === "person" && drag.current.moved) persist();
		drag.current = null;
	};
	const hint = tool === "add" ? "Pulsa el lienzo para colocar a una persona" : tool === "link" ? linkFrom ? "Elige la segunda persona" : "Elige la primera persona" : null;
	const nameOf = (id) => persons.find((p) => p.id === id)?.name ?? id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: wrapRef,
		className: "relative min-h-0 flex-1 overflow-hidden bg-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0",
				style: {
					backgroundImage: "linear-gradient(to right, color-mix(in oklab, var(--color-ink) 7%, transparent) 1px, transparent 1px), linear-gradient(to bottom, color-mix(in oklab, var(--color-ink) 7%, transparent) 1px, transparent 1px)",
					backgroundSize: "24px 24px"
				}
			}),
			persons.length === 0 && !draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-10 flex flex-col items-center justify-center px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {
						className: "mb-3 size-8 text-muted-foreground/45",
						strokeWidth: 1.4
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium tracking-tight",
						children: "El mapa se dibuja aquí"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 max-w-sm text-sm text-muted-foreground",
						children: "Genera una familia desde texto, o pulsa Añadir y toca el lienzo."
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				ref: svgRef,
				className: cn("relative z-[1] h-full w-full touch-none select-none", tool === "add" ? "cursor-crosshair" : tool === "link" ? "cursor-pointer" : ""),
				onPointerDown: onPointerDownBg,
				onPointerMove,
				onPointerUp,
				onPointerCancel: onPointerUp,
				onDoubleClick: (e) => {
					e.preventDefault();
					placeDraft(e.clientX, e.clientY);
					setTool("add");
				},
				"data-world-svg": true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					"data-world": true,
					transform: `translate(${view.x} ${view.y}) scale(${view.k})`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RelLayer, {
						persons,
						relationships
					}), persons.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonMark, {
						person: p,
						selected: p.id === selectedId,
						linking: tool === "link" && (linkFrom === p.id || linkMenu?.a === p.id || linkMenu?.b === p.id),
						onPointerDown: (e) => onPointerDownPerson(e, p)
					}, p.id))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-3 left-3 z-10 flex gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: tool === "add" ? "default" : "outline",
					size: "sm",
					className: cn("h-10", tool !== "add" && "bg-card"),
					onClick: () => {
						setTool((t) => t === "add" ? "select" : "add");
						setLinkFrom(null);
						setLinkMenu(null);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: "Añadir"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: tool === "link" ? "default" : "outline",
					size: "sm",
					className: cn("h-10", tool !== "link" && "bg-card"),
					disabled: persons.length < 2,
					onClick: () => {
						setTool((t) => t === "link" ? "select" : "link");
						setLinkFrom(null);
						setLinkMenu(null);
						setDraft(null);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: "Vincular"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-3 right-3 z-10 flex gap-1.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "icon",
						className: "size-10 bg-card",
						onClick: () => zoomBy(1.15),
						"aria-label": "Acercar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "icon",
						className: "size-10 bg-card",
						onClick: () => zoomBy(.87),
						"aria-label": "Alejar",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "icon",
						className: "size-10 bg-card",
						onClick: fit,
						"aria-label": "Ajustar a la vista",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, {})
					})
				]
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute top-16 left-1/2 z-10 -translate-x-1/2 rounded-md bg-bar px-3 py-1.5 text-xs font-medium text-bar-foreground shadow-[var(--shadow-border)]",
				children: hint
			}) : null,
			draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "absolute top-1/2 left-1/2 z-20 w-[min(92vw,280px)] -translate-x-1/2 -translate-y-1/2 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
				onSubmit: (e) => {
					e.preventDefault();
					confirmDraft();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium tracking-tight",
						children: "Nueva persona"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-xs font-medium tracking-wide text-muted-foreground",
						children: ["Nombre", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							ref: draftNameRef,
							className: "mt-1.5",
							value: draft.name,
							placeholder: "Nombre",
							onChange: (e) => setDraft({
								...draft,
								name: e.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-xs font-medium tracking-wide text-muted-foreground",
						children: ["Género", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "mt-1.5 h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
							value: draft.gender,
							onChange: (e) => setDraft({
								...draft,
								gender: e.target.value
							}),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "female",
									children: "Mujer"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "male",
									children: "Hombre"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "unknown",
									children: "Desconocido"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex justify-end gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => setDraft(null),
							children: "Cancelar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: !draft.name.trim(),
							children: "Añadir"
						})]
					})
				]
			}) : null,
			linkMenu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-1/2 left-1/2 z-20 w-[min(92vw,280px)] -translate-x-1/2 -translate-y-1/2 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-medium tracking-tight",
						children: "Vínculo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							nameOf(linkMenu.a),
							" → ",
							nameOf(linkMenu.b)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid max-h-64 grid-cols-1 gap-1 overflow-y-auto",
						children: LINK_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-10 rounded-md px-3 text-left text-sm hover:bg-accent",
							onClick: () => {
								addRelationship(t, linkMenu.a, linkMenu.b);
								setLinkMenu(null);
								setTool("select");
							},
							children: REL_LABELS[t]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						className: "mt-3 w-full",
						onClick: () => setLinkMenu(null),
						children: "Cancelar"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("absolute bottom-3 left-3 z-10 hidden rounded-xl bg-card/95 p-3 text-[11px] text-muted-foreground shadow-[var(--shadow-border)] sm:block"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-1.5 font-semibold uppercase tracking-[0.08em] text-foreground/70",
					children: "Leyenda"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-x-4 gap-y-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block size-3 border-2 border-ink bg-male" }), " Hombre"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block size-3 rounded-full border-2 border-ink bg-female" }), " Mujer"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "relative inline-block size-3 border-2 border-ink bg-deceased after:absolute after:inset-0 after:flex after:items-center after:justify-center after:text-[10px] after:content-['×']" }), " Fallecido"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0 w-4 border-t-2 border-ink" }), " Matrimonio"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0 w-4 border-t-2 border-dashed border-ink" }), " Unión / sep."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0 w-4 border-t-2 border-ink" }), " Hijos"]
						})
					]
				})]
			})
		]
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("mb-1.5 block text-xs font-medium tracking-wide text-muted-foreground", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-36 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/35 disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var parseFamilyWithAi = createServerFn({ method: "POST" }).validator((input) => {
	const text = (input?.text ?? "").trim();
	if (!text) throw new Error("Escribe un texto primero.");
	if (text.length > 8e3) throw new Error("El texto es demasiado largo.");
	return { text };
}).handler(createSsrRpc("b7f8f9b8bc6d10585e646706f186bf1fad3c0236ae37207e24a4b5174609c6df"));
function Separator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("h-px w-full bg-border", className),
		...props
	});
}
var selectClass$1 = "h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/35";
function PersonInspector({ person }) {
	const updatePerson = useGenogram((s) => s.updatePerson);
	const removePerson = useGenogram((s) => s.removePerson);
	const removeRelationship = useGenogram((s) => s.removeRelationship);
	const relationships = useGenogram((s) => s.relationships);
	const persons = useGenogram((s) => s.persons);
	const checkpoint = useGenogram((s) => s.checkpoint);
	const [name, setName] = (0, import_react.useState)(person.name);
	const [occupation, setOccupation] = (0, import_react.useState)(person.occupation);
	const [notes, setNotes] = (0, import_react.useState)(person.notes);
	const [age, setAge] = (0, import_react.useState)(person.age?.toString() ?? "");
	const [birthYear, setBirthYear] = (0, import_react.useState)(person.birthYear?.toString() ?? "");
	const [deathYear, setDeathYear] = (0, import_react.useState)(person.deathYear?.toString() ?? "");
	(0, import_react.useEffect)(() => {
		setName(person.name);
		setOccupation(person.occupation);
		setNotes(person.notes);
		setAge(person.age?.toString() ?? "");
		setBirthYear(person.birthYear?.toString() ?? "");
		setDeathYear(person.deathYear?.toString() ?? "");
	}, [
		person.id,
		person.name,
		person.occupation,
		person.notes,
		person.age,
		person.birthYear,
		person.deathYear
	]);
	const related = relationships.filter((r) => r.a === person.id || r.b === person.id);
	const nameOf = (id) => persons.find((p) => p.id === id)?.name ?? id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-lg font-medium tracking-tight",
				children: person.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Seleccionado en el mapa"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "edit-name",
				children: "Nombre"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "edit-name",
				value: name,
				onFocus: () => checkpoint(),
				onChange: (e) => {
					setName(e.target.value);
					updatePerson(person.id, { name: e.target.value }, { history: false });
				}
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "edit-gender",
					children: "Género"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					id: "edit-gender",
					className: selectClass$1,
					value: person.gender,
					onChange: (e) => updatePerson(person.id, { gender: e.target.value }),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "male",
							children: "Hombre"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "female",
							children: "Mujer"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "unknown",
							children: "Desconocido"
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "edit-age",
					children: "Edad"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "edit-age",
					inputMode: "numeric",
					value: age,
					onFocus: () => checkpoint(),
					onChange: (e) => {
						setAge(e.target.value);
						const n = e.target.value === "" ? null : Number(e.target.value);
						updatePerson(person.id, { age: n != null && Number.isFinite(n) ? n : null }, { history: false });
					}
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "edit-birth",
					children: "Nacimiento"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "edit-birth",
					inputMode: "numeric",
					placeholder: "año",
					value: birthYear,
					onFocus: () => checkpoint(),
					onChange: (e) => {
						setBirthYear(e.target.value);
						const n = e.target.value === "" ? null : Number(e.target.value);
						updatePerson(person.id, { birthYear: n != null && Number.isFinite(n) ? n : null }, { history: false });
					}
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "edit-death",
					children: "Defunción"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "edit-death",
					inputMode: "numeric",
					placeholder: "año",
					value: deathYear,
					onFocus: () => checkpoint(),
					onChange: (e) => {
						setDeathYear(e.target.value);
						const n = e.target.value === "" ? null : Number(e.target.value);
						updatePerson(person.id, {
							deathYear: n != null && Number.isFinite(n) ? n : null,
							deceased: n != null && Number.isFinite(n) ? true : person.deceased
						}, { history: false });
					}
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-10 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "size-4 accent-primary",
					checked: person.deceased,
					onChange: (e) => updatePerson(person.id, { deceased: e.target.checked })
				}), "Fallecido/a"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex min-h-10 items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					className: "size-4 accent-primary",
					checked: person.identifiedPatient,
					onChange: (e) => updatePerson(person.id, { identifiedPatient: e.target.checked })
				}), "Paciente identificado (doble trazo)"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "edit-occ",
				children: "Ocupación"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "edit-occ",
				value: occupation,
				onFocus: () => checkpoint(),
				onChange: (e) => {
					setOccupation(e.target.value);
					updatePerson(person.id, { occupation: e.target.value }, { history: false });
				}
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: "edit-notes",
				children: "Notas clínicas"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: "edit-notes",
				value: notes,
				onFocus: () => checkpoint(),
				onChange: (e) => {
					setNotes(e.target.value);
					updatePerson(person.id, { notes: e.target.value }, { history: false });
				}
			})] }),
			related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Vínculos" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-1",
				children: related.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-2 rounded-md bg-secondary px-2 py-1.5 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 truncate",
						children: [
							REL_LABELS[r.type],
							" · ",
							nameOf(r.a === person.id ? r.b : r.a)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "shrink-0 text-muted-foreground hover:text-destructive",
						onClick: () => removeRelationship(r.id),
						"aria-label": "Quitar vínculo",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
					})]
				}, r.id))
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "destructive",
				className: "w-full",
				onClick: () => removePerson(person.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Eliminar persona"]
			})
		]
	});
}
var selectClass = "h-11 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/35";
function Sidebar() {
	const [text, setText] = (0, import_react.useState)(EXAMPLE_TEXT);
	const [aiBusy, setAiBusy] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [gender, setGender] = (0, import_react.useState)("female");
	const [age, setAge] = (0, import_react.useState)("");
	const [deceased, setDeceased] = (0, import_react.useState)(false);
	const [fromId, setFromId] = (0, import_react.useState)("");
	const [toId, setToId] = (0, import_react.useState)("");
	const [relType, setRelType] = (0, import_react.useState)("marriage");
	const persons = useGenogram((s) => s.persons);
	const selectedId = useGenogram((s) => s.selectedId);
	const select = useGenogram((s) => s.select);
	const status = useGenogram((s) => s.status);
	const tab = useGenogram((s) => s.sidebarTab);
	const setTab = useGenogram((s) => s.setSidebarTab);
	const loadFromText = useGenogram((s) => s.loadFromText);
	const loadData = useGenogram((s) => s.loadData);
	const addPerson = useGenogram((s) => s.addPerson);
	const addRelationship = useGenogram((s) => s.addRelationship);
	const selected = persons.find((p) => p.id === selectedId) ?? null;
	const preview = (0, import_react.useMemo)(() => text.trim() ? parseFamilyText(text) : {
		persons: [],
		relationships: []
	}, [text]);
	function submitPerson() {
		if (addPerson({
			name,
			gender,
			age: age === "" ? null : Number(age),
			deceased
		})) {
			setName("");
			setAge("");
			setDeceased(false);
		}
	}
	async function generateAi() {
		if (!text.trim()) return;
		setAiBusy(true);
		try {
			const res = await parseFamilyWithAi({ data: { text } });
			if (res.ok) loadData(res.data, `IA: ${res.data.persons.length} personas, ${res.data.relationships.length} vínculos.`);
			else {
				const local = loadFromText(text);
				useGenogram.setState({ status: local.ok ? `${res.error} Se usó el analizador local.` : res.error });
			}
		} catch {
			loadFromText(text);
			useGenogram.setState({ status: "IA no disponible. Se usó el analizador local." });
		} finally {
			setAiBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex h-full min-h-0 w-full flex-col border-border bg-card lg:w-[320px] lg:border-r",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 border-b border-border",
				children: [
					["texto", "Texto"],
					["manual", "Manual"],
					["personas", "Ficha"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("h-11 border-b-2 text-sm font-medium transition-colors duration-150", tab === id ? "border-foreground text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"),
					onClick: () => setTab(id),
					children: label
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto p-4",
				children: [
					tab === "texto" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1.5 flex items-end justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "family-text",
								className: "mb-0",
								children: "Descripción familiar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-xs font-medium text-primary underline-offset-2 hover:underline",
								onClick: () => setText(EXAMPLE_TEXT),
								children: "Cargar ejemplo"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "family-text",
							value: text,
							onChange: (e) => setText(e.target.value),
							placeholder: "María está casada con Juan. Tienen dos hijos: Laura y Pedro."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 mt-2 text-xs text-muted-foreground",
							children: "Nombres, edades, matrimonio, hijos, padres, fallecimiento, hermanos, conflicto. También vale en minúsculas o en primera persona («estoy casada», «tengo dos hijos»)."
						}),
						preview.persons.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 rounded-lg bg-secondary px-3 py-2 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium text-foreground",
									children: [
										preview.persons.length,
										" persona",
										preview.persons.length === 1 ? "" : "s"
									]
								}),
								" · ",
								preview.relationships.length,
								" vínculo",
								preview.relationships.length === 1 ? "" : "s",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1.5 flex flex-wrap gap-1",
									children: preview.persons.slice(0, 12).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-card px-2 py-0.5 text-[11px] text-foreground",
										children: p.name
									}, p.id))
								})
							]
						}) : text.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-xs text-destructive",
							children: "No se detectan nombres todavía."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							className: "h-11 w-full",
							onClick: () => loadFromText(text),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WandSparkles, {}), " Generar genograma"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							className: "mt-2 h-11 w-full",
							disabled: aiBusy,
							onClick: generateAi,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}),
								" ",
								aiBusy ? "Interpretando…" : "Generar con IA"
							]
						})
					] }) : null,
					tab === "manual" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "new-name",
							children: "Añadir persona"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "new-name",
							value: name,
							placeholder: "Nombre",
							onChange: (e) => setName(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter") submitPerson();
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "new-gender",
								children: "Género"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "new-gender",
								className: selectClass,
								value: gender,
								onChange: (e) => setGender(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "male",
										children: "Hombre"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "female",
										children: "Mujer"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "unknown",
										children: "Desconocido"
									})
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "new-age",
								children: "Edad"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "new-age",
								inputMode: "numeric",
								value: age,
								onChange: (e) => setAge(e.target.value)
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-2 flex min-h-11 items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "size-4 accent-primary",
								checked: deceased,
								onChange: (e) => setDeceased(e.target.checked)
							}), "Fallecido/a"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							className: "mt-2 h-11 w-full",
							onClick: submitPerson,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, {}), " Añadir persona"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-5 h-px bg-border" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Crear vínculo" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: cn(selectClass, "mb-2"),
							value: fromId || selectedId || "",
							onChange: (e) => setFromId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Persona 1…"
							}), persons.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: cn(selectClass, "mb-2"),
							value: relType,
							onChange: (e) => setRelType(e.target.value),
							children: Object.keys(REL_LABELS).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: t,
								children: REL_LABELS[t]
							}, t))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: cn(selectClass, "mb-3"),
							value: toId,
							onChange: (e) => setToId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Persona 2…"
							}), persons.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "h-11 w-full",
							onClick: () => addRelationship(relType, fromId || selectedId || "", toId),
							children: "Crear vínculo"
						})
					] }) : null,
					tab === "personas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonInspector, { person: selected }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Selecciona a alguien en el mapa o en la lista."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Personas" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-1 space-y-0.5",
							children: persons.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-sm italic text-muted-foreground",
								children: "Ninguna todavía"
							}) : persons.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => select(p.id),
								className: cn("flex min-h-11 w-full items-center gap-2 rounded-md px-2 text-left text-sm", selectedId === p.id ? "bg-accent text-foreground" : "hover:bg-secondary"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 shrink-0 border border-ink", p.gender === "female" ? "rounded-full bg-female" : p.gender === "male" ? "bg-male" : "rotate-45 bg-unknown") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "truncate",
									children: [
										p.name,
										p.age != null ? ` (${p.age})` : "",
										p.deceased ? " †" : ""
									]
								})]
							}) }, p.id))
						})] })]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border px-4 py-2.5 text-xs text-muted-foreground",
				children: status
			})
		]
	});
}
function GenogramApp() {
	const hydrate = useGenogram((s) => s.hydrate);
	const hydrated = useGenogram((s) => s.hydrated);
	const persons = useGenogram((s) => s.persons);
	const relationships = useGenogram((s) => s.relationships);
	const layout = useGenogram((s) => s.layout);
	const undo = useGenogram((s) => s.undo);
	const redo = useGenogram((s) => s.redo);
	const clear = useGenogram((s) => s.clear);
	const loadData = useGenogram((s) => s.loadData);
	const select = useGenogram((s) => s.select);
	const selectedId = useGenogram((s) => s.selectedId);
	const removePerson = useGenogram((s) => s.removePerson);
	const past = useGenogram((s) => s.past);
	const future = useGenogram((s) => s.future);
	const panel = useGenogram((s) => s.panel);
	const setPanel = useGenogram((s) => s.setPanel);
	const svgRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const selected = persons.find((p) => p.id === selectedId) ?? null;
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			const t = e.target;
			const typing = t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable);
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z") {
				e.preventDefault();
				if (e.shiftKey) redo();
				else undo();
				return;
			}
			if (typing) return;
			if ((e.key === "Delete" || e.key === "Backspace") && selectedId) {
				e.preventDefault();
				removePerson(selectedId);
			}
			if (e.key === "Escape") select(null);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		undo,
		redo,
		selectedId,
		removePerson,
		select
	]);
	function preparedSvg() {
		const svg = svgRef.current;
		if (!svg || persons.length === 0) return null;
		const clone = svg.cloneNode(true);
		clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
		clone.querySelector("[data-world]")?.removeAttribute("transform");
		const box = boundingBox(persons, 70, 800, 500);
		clone.setAttribute("viewBox", `${box.minX} ${box.minY} ${box.width} ${box.height}`);
		clone.setAttribute("width", String(Math.round(box.width)));
		clone.setAttribute("height", String(Math.round(box.height)));
		const bg = document.createElementNS("http://www.w3.org/2000/svg", "rect");
		bg.setAttribute("x", String(box.minX));
		bg.setAttribute("y", String(box.minY));
		bg.setAttribute("width", String(box.width));
		bg.setAttribute("height", String(box.height));
		bg.setAttribute("fill", "#f7f8fa");
		clone.insertBefore(bg, clone.firstChild);
		return clone;
	}
	async function onExportPng() {
		const clone = preparedSvg();
		if (!clone) return;
		await exportPngElement(clone);
		useGenogram.setState({ status: "PNG descargado." });
	}
	function onExportSvg() {
		const clone = preparedSvg();
		if (!clone) return;
		exportSvgElement(clone);
		useGenogram.setState({ status: "SVG descargado." });
	}
	function onExportJson() {
		downloadBlob("genograma.json", new Blob([JSON.stringify({
			persons,
			relationships
		}, null, 2)], { type: "application/json" }));
		useGenogram.setState({ status: "JSON descargado." });
	}
	function onImportJson(file) {
		const reader = new FileReader();
		reader.onload = () => {
			try {
				const parsed = JSON.parse(String(reader.result));
				if (!Array.isArray(parsed.persons)) throw new Error("invalid");
				loadData({
					persons: parsed.persons,
					relationships: parsed.relationships ?? []
				}, "Archivo importado.");
			} catch {
				useGenogram.setState({ status: "No se pudo leer ese JSON." });
			}
		};
		reader.readAsText(file);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh min-h-0 flex-col bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-12 shrink-0 items-center justify-between gap-3 bg-bar px-3 text-bar-foreground sm:px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-baseline gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-lg leading-none font-medium italic tracking-tight",
						children: "Genograma"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden text-xs tracking-wide text-bar-foreground/55 sm:block",
						children: "ficha familiar"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							className: "size-10 text-bar-foreground hover:bg-white/10 hover:text-bar-foreground",
							disabled: past.length === 0,
							onClick: undo,
							"aria-label": "Deshacer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							className: "size-10 text-bar-foreground hover:bg-white/10 hover:text-bar-foreground",
							disabled: future.length === 0,
							onClick: redo,
							"aria-label": "Rehacer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							className: "hidden text-bar-foreground hover:bg-white/10 hover:text-bar-foreground sm:inline-flex",
							onClick: layout,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnfoldHorizontal, {}), " Organizar"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							className: "size-10 text-bar-foreground hover:bg-white/10 hover:text-bar-foreground sm:hidden",
							onClick: layout,
							"aria-label": "Organizar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnfoldHorizontal, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							className: "hidden text-bar-foreground hover:bg-white/10 hover:text-bar-foreground md:inline-flex",
							onClick: onExportSvg,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " SVG"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							size: "sm",
							className: "bg-bar-foreground text-bar hover:opacity-90",
							onClick: onExportPng,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " PNG"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							className: "size-10 hidden text-bar-foreground hover:bg-white/10 hover:text-bar-foreground sm:inline-flex",
							onClick: onExportJson,
							"aria-label": "Exportar JSON",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileJson, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							className: "size-10 hidden text-bar-foreground hover:bg-white/10 hover:text-bar-foreground sm:inline-flex",
							onClick: () => fileRef.current?.click(),
							"aria-label": "Importar JSON",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: fileRef,
							type: "file",
							accept: "application/json",
							className: "hidden",
							onChange: (e) => {
								const f = e.target.files?.[0];
								if (f) onImportJson(f);
								e.target.value = "";
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon",
								className: "size-10 text-bar-foreground hover:bg-white/10 hover:text-bar-foreground",
								"aria-label": "Limpiar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "¿Vaciar el genograma?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "Se quitan todas las personas y vínculos de este documento. Puedes deshacerlo después." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancelar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
							onClick: clear,
							children: "Vaciar"
						})] })] })] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("min-h-0 lg:flex lg:w-[320px] lg:shrink-0", panel === "datos" ? "flex h-full" : "hidden"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("relative min-h-0 min-w-0 flex-1 flex-col", panel === "lienzo" ? "flex" : "hidden lg:flex"),
					children: [hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenogramCanvas, { svgRef }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1 bg-paper" }), selected && panel === "lienzo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute right-3 bottom-3 left-3 z-20 rounded-lg bg-card p-3 shadow-[var(--shadow-border)] lg:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-medium",
									children: selected.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										selected.gender === "female" ? "Mujer" : selected.gender === "male" ? "Hombre" : "Género desconocido",
										selected.age != null ? ` · ${selected.age} años` : "",
										selected.deceased ? " · fallecido/a" : ""
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								onClick: () => {
									useGenogram.getState().setSidebarTab("personas");
									setPanel("datos");
								},
								children: "Editar"
							})]
						})
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "grid h-12 shrink-0 grid-cols-2 border-t border-border bg-card pb-[env(safe-area-inset-bottom)] lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("text-sm font-medium", panel === "datos" ? "text-foreground" : "text-muted-foreground"),
					onClick: () => setPanel("datos"),
					children: "Datos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("text-sm font-medium", panel === "lienzo" ? "text-foreground" : "text-muted-foreground"),
					onClick: () => setPanel("lienzo"),
					children: "Lienzo"
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GenogramApp, {});
}
//#endregion
export { Home as component };
