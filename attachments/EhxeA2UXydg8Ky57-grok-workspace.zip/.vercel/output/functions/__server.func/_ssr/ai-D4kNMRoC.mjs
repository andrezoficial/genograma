import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { i as emptyPerson, o as inferGenderFromName } from "./gender-IpsWIfkz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-D4kNMRoC.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var REL_TYPES = [
	"marriage",
	"cohabitation",
	"separation",
	"divorce",
	"parent_child",
	"adopted",
	"sibling",
	"close",
	"distant",
	"cutoff",
	"conflict"
];
function normGender(value) {
	const v = (value ?? "").toLowerCase();
	if (v === "male" || v === "m" || v === "hombre" || v === "masculino") return "male";
	if (v === "female" || v === "f" || v === "mujer" || v === "femenino") return "female";
	return "unknown";
}
function mapAi(persons, rels) {
	const nameToId = /* @__PURE__ */ new Map();
	const outPersons = persons.map((p, i) => {
		const name = (p.name ?? "").trim();
		if (!name) return null;
		const id = `p${i + 1}`;
		nameToId.set(name.toLowerCase(), id);
		return emptyPerson({
			id,
			name,
			gender: p.gender ? normGender(p.gender) : inferGenderFromName(name),
			age: typeof p.age === "number" ? p.age : null,
			birthYear: typeof p.birthYear === "number" ? p.birthYear : null,
			deathYear: typeof p.deathYear === "number" ? p.deathYear : null,
			deceased: Boolean(p.deceased) || typeof p.deathYear === "number",
			occupation: p.occupation ?? "",
			notes: p.notes ?? "",
			identifiedPatient: Boolean(p.identifiedPatient)
		});
	}).filter((p) => p != null);
	const outRels = [];
	let ri = 1;
	for (const r of rels) {
		const a = nameToId.get((r.from ?? "").trim().toLowerCase());
		const b = nameToId.get((r.to ?? "").trim().toLowerCase());
		const type = REL_TYPES.includes(r.type) ? r.type : null;
		if (!a || !b || !type || a === b) continue;
		outRels.push({
			id: `r${ri++}`,
			type,
			a,
			b
		});
	}
	return {
		persons: outPersons,
		relationships: outRels
	};
}
var parseFamilyWithAi_createServerFn_handler = createServerRpc({
	id: "b7f8f9b8bc6d10585e646706f186bf1fad3c0236ae37207e24a4b5174609c6df",
	name: "parseFamilyWithAi",
	filename: "src/lib/genogram/ai.ts"
}, (opts) => parseFamilyWithAi.__executeServer(opts));
var parseFamilyWithAi = createServerFn({ method: "POST" }).validator((input) => {
	const text = (input?.text ?? "").trim();
	if (!text) throw new Error("Escribe un texto primero.");
	if (text.length > 8e3) throw new Error("El texto es demasiado largo.");
	return { text };
}).handler(parseFamilyWithAi_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env["XAI_API_KEY"]?.trim();
	if (!apiKey) return {
		ok: false,
		error: "La generación con IA no está disponible ahora."
	};
	let res;
	try {
		res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			signal: AbortSignal.timeout(45e3),
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: 0,
				max_tokens: 1800,
				response_format: { type: "json_object" },
				messages: [{
					role: "system",
					content: "Eres un experto en genogramas clínicos. Extrae personas y vínculos de una descripción familiar en español. Responde SOLO JSON válido con esta forma: {\"persons\":[{\"name\",\"gender\":\"male|female|unknown\",\"age\":null,\"birthYear\":null,\"deathYear\":null,\"deceased\":false,\"occupation\":\"\",\"notes\":\"\",\"identifiedPatient\":false}],\"relationships\":[{\"type\":\"marriage|cohabitation|separation|divorce|parent_child|adopted|sibling|close|distant|cutoff|conflict\",\"from\":\"Nombre\",\"to\":\"Nombre\"}]}. En parent_child, from es el progenitor y to el hijo. No inventes gente que no esté en el texto. Si un hermano comparte padres, incluye también parent_child a esos padres."
				}, {
					role: "user",
					content: data.text
				}]
			})
		});
	} catch {
		return {
			ok: false,
			error: "No se pudo interpretar el texto con IA."
		};
	}
	if (!res.ok) return {
		ok: false,
		error: "No se pudo interpretar el texto con IA."
	};
	const jsonStr = ((await res.json()).choices?.[0]?.message?.content ?? "").replace(/```(?:json)?/gi, "").trim();
	try {
		const parsed = JSON.parse(jsonStr);
		const mapped = mapAi(parsed.persons ?? [], parsed.relationships ?? []);
		if (mapped.persons.length === 0) return {
			ok: false,
			error: "La IA no encontró personas en el texto."
		};
		return {
			ok: true,
			data: mapped
		};
	} catch {
		return {
			ok: false,
			error: "La IA devolvió un resultado ilegible."
		};
	}
});
//#endregion
export { parseFamilyWithAi_createServerFn_handler };
