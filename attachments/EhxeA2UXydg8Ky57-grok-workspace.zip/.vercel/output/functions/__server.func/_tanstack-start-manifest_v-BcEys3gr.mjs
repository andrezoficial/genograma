//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BcEys3gr.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CqR2IHHN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CqR2IHHN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C6nk2Lz5.js"]
	}
} });
//#endregion
export { tsrStartManifest };
